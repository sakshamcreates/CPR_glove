import React from 'react';
import { MetricCard } from '../common/MetricCard';
import { StatusIndicator } from '../common/StatusIndicator';
import { AccelerationChart } from './AccelerationChart';
import { Activity, ShieldCheck, Compass, Sparkles } from 'lucide-react';

export const DashboardMockup: React.FC = () => {
  return (
    <div className="w-full rounded-xl border border-border bg-white shadow-elevated overflow-hidden">
      {/* Top Header */}
      <div className="bg-canvas-secondary/80 px-4 sm:px-6 py-3.5 border-b border-border flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-status-success" />
            <span className="font-mono text-xs font-bold text-content-primary tracking-tight">
              LIVE MONITOR
            </span>
          </div>
          <span className="text-content-muted text-xs">|</span>
          <span className="font-mono text-[11px] text-content-secondary">
            SANJEEVANI-01
          </span>
        </div>

        <div className="flex items-center gap-2.5">
          <StatusIndicator variant="cpr" cprStatus="OPTIMAL" size="sm" label="OPTIMAL RHYTHM" />
          <StatusIndicator variant="demo" label="DEMO PREVIEW" size="sm" />
        </div>
      </div>

      {/* Main Metric Grid */}
      <div className="p-4 sm:p-6 bg-canvas-primary/30">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 mb-4 sm:mb-6">
          {/* CPR Rate */}
          <MetricCard
            label="CPR RATE"
            value="112"
            unit="/min"
            target="100–120 Target"
            highlight={true}
            statusBadge={
              <span className="flex items-center gap-1 text-[11px] font-mono font-medium text-status-success">
                <Activity className="w-3 h-3" /> IN TARGET
              </span>
            }
          />

          {/* Compression Count */}
          <MetricCard
            label="COMPRESSIONS"
            value="18 / 30"
            statusBadge={
              <span className="flex items-center gap-1 text-[11px] font-mono text-content-secondary">
                <ShieldCheck className="w-3 h-3 text-brand-green" /> ACTIVE
              </span>
            }
          />

          {/* Hand Position */}
          <MetricCard
            label="HAND POSITION"
            value="Optimal"
            statusBadge={
              <span className="flex items-center gap-1 text-[11px] font-mono text-status-success">
                <Compass className="w-3 h-3" /> ALIGNED
              </span>
            }
          />

          {/* Motion */}
          <MetricCard
            label="MOTION"
            value="Stable"
            statusBadge={
              <span className="flex items-center gap-1 text-[11px] font-mono text-brand-green">
                <Sparkles className="w-3 h-3" /> CONSISTENT
              </span>
            }
          />
        </div>

        {/* Live Motion Waveform */}
        <div>
          <AccelerationChart mode="demo" height={110} title="Live Motion" />
        </div>
      </div>
    </div>
  );
};
