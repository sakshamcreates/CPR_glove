import React from 'react';

interface AccelerationChartProps {
  mode?: 'demo' | 'empty';
  height?: number;
  className?: string;
  title?: string;
}

export const AccelerationChart: React.FC<AccelerationChartProps> = ({
  mode = 'empty',
  height = 130,
  className = '',
  title = 'Live Motion',
}) => {
  if (mode === 'empty') {
    return (
      <div
        className={`w-full rounded-lg border border-dashed border-border bg-canvas-secondary/30 flex flex-col items-center justify-center p-6 text-center ${className}`}
        style={{ minHeight: `${height}px` }}
      >
        <div className="font-mono text-xs font-semibold text-content-secondary uppercase tracking-wider mb-1">
          {title}
        </div>
        <p className="text-xs text-content-muted font-mono">
          Waiting for sensor data...
        </p>
      </div>
    );
  }

  // Representative motion waveform for demo preview
  const points = [
    { x: 10, y: 65 },
    { x: 30, y: 65 },
    // Cycle 1
    { x: 45, y: 100 },
    { x: 60, y: 20 },
    { x: 75, y: 85 },
    { x: 90, y: 65 },
    { x: 110, y: 65 },
    // Cycle 2
    { x: 125, y: 102 },
    { x: 140, y: 18 },
    { x: 155, y: 88 },
    { x: 170, y: 65 },
    { x: 190, y: 65 },
    // Cycle 3
    { x: 205, y: 98 },
    { x: 220, y: 22 },
    { x: 235, y: 84 },
    { x: 250, y: 65 },
    { x: 270, y: 65 },
    // Cycle 4
    { x: 285, y: 100 },
    { x: 300, y: 20 },
    { x: 315, y: 86 },
    { x: 330, y: 65 },
    { x: 350, y: 65 },
    { x: 390, y: 65 },
  ];

  const pathD = points.reduce((acc, pt, idx) => {
    return idx === 0 ? `M ${pt.x} ${pt.y}` : `${acc} L ${pt.x} ${pt.y}`;
  }, '');

  return (
    <div className={`w-full rounded-lg border border-border bg-white/90 p-4 shadow-subtle ${className}`}>
      {/* Chart Header */}
      <div className="flex items-center justify-between text-[11px] font-mono text-content-secondary border-b border-border/60 pb-2 mb-3">
        <div className="flex items-center gap-2">
          <span className="w-1.5 h-1.5 rounded-full bg-brand-green" />
          <span className="font-semibold text-content-primary uppercase">{title}</span>
        </div>
        <span className="text-content-muted">Compression Waveform</span>
      </div>

      {/* SVG Waveform Graphic */}
      <div className="relative w-full" style={{ height: `${height}px` }}>
        <svg
          viewBox="0 0 400 120"
          preserveAspectRatio="none"
          className="w-full h-full"
        >
          {/* Subtle Grid Horizontal Lines */}
          <line x1="0" y1="25" x2="400" y2="25" stroke="#ECE8DE" strokeWidth="1" strokeDasharray="3 3" />
          <line x1="0" y1="65" x2="400" y2="65" stroke="#D8D4C9" strokeWidth="1" />
          <line x1="0" y1="105" x2="400" y2="105" stroke="#ECE8DE" strokeWidth="1" strokeDasharray="3 3" />

          {/* Acceleration Waveform Path */}
          <path
            d={pathD}
            fill="none"
            stroke="#173F35"
            strokeWidth="1.75"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>
      </div>
    </div>
  );
};
