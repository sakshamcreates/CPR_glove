import React from 'react';
import { ConnectionState, CPRStatus } from '../../types/cpr';

interface StatusIndicatorProps {
  status?: ConnectionState;
  cprStatus?: CPRStatus;
  label?: string;
  variant?: 'connection' | 'cpr' | 'demo';
  size?: 'sm' | 'md';
}

export const StatusIndicator: React.FC<StatusIndicatorProps> = ({
  status = 'OFFLINE',
  cprStatus,
  label,
  variant = 'connection',
  size = 'md',
}) => {
  if (variant === 'demo') {
    return (
      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-mono font-medium tracking-wide uppercase bg-canvas-muted text-content-secondary border border-border rounded">
        <span className="w-1.5 h-1.5 rounded-full bg-content-muted" />
        {label || 'DEMO PREVIEW'}
      </span>
    );
  }

  if (variant === 'cpr' && cprStatus) {
    const config: Record<CPRStatus, { text: string; bg: string; textCol: string; dot: string }> = {
      OPTIMAL: {
        text: 'OPTIMAL',
        bg: 'bg-emerald-50',
        textCol: 'text-status-success',
        dot: 'bg-status-success',
      },
      TOO_SLOW: {
        text: 'TOO SLOW',
        bg: 'bg-amber-50',
        textCol: 'text-status-warning',
        dot: 'bg-status-warning',
      },
      TOO_FAST: {
        text: 'TOO FAST',
        bg: 'bg-amber-50',
        textCol: 'text-status-warning',
        dot: 'bg-status-warning',
      },
      POSITION_ALERT: {
        text: 'ADJUST ANGLE',
        bg: 'bg-red-50',
        textCol: 'text-status-danger',
        dot: 'bg-status-danger',
      },
      PAUSE_WARNING: {
        text: 'PAUSE DETECTED',
        bg: 'bg-red-50',
        textCol: 'text-status-danger',
        dot: 'bg-status-danger',
      },
      CRITICAL: {
        text: 'CRITICAL',
        bg: 'bg-red-50',
        textCol: 'text-status-danger',
        dot: 'bg-status-danger',
      },
    };

    const current = config[cprStatus] || config.OPTIMAL;

    return (
      <span className={`inline-flex items-center gap-1.5 ${size === 'sm' ? 'px-2 py-0.5 text-[11px]' : 'px-2.5 py-1 text-xs'} font-mono font-medium tracking-wider uppercase ${current.bg} ${current.textCol} border border-border rounded`}>
        <span className={`w-1.5 h-1.5 rounded-full ${current.dot}`} />
        {label || current.text}
      </span>
    );
  }

  // Connection variant (Default)
  const isOnline = status === 'CONNECTED';
  const isConnecting = status === 'CONNECTING' || status === 'CALIBRATING';

  return (
    <span className={`inline-flex items-center gap-1.5 ${size === 'sm' ? 'px-2 py-0.5 text-[11px]' : 'px-2.5 py-1 text-xs'} font-mono font-medium tracking-wide text-content-secondary bg-canvas-secondary border border-border rounded`}>
      <span
        className={`w-1.5 h-1.5 rounded-full ${
          isOnline
            ? 'bg-status-success'
            : isConnecting
            ? 'bg-status-warning animate-pulse'
            : 'bg-content-muted'
        }`}
      />
      {label || (status === 'OFFLINE' ? 'Glove Offline' : status === 'CONNECTED' ? 'Glove Online' : status)}
    </span>
  );
};
