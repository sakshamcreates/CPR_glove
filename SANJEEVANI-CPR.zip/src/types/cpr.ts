export type CPRStatus =
  | "OPTIMAL"
  | "TOO_SLOW"
  | "TOO_FAST"
  | "POSITION_ALERT"
  | "PAUSE_WARNING"
  | "CRITICAL";

export interface CPRData {
  compressionCount: number;
  targetCount: number;
  rate: number;
  acceleration: number;
  peakAcceleration: number;
  tilt: number;
  status: CPRStatus;
  timestamp?: number;
}

export type ConnectionState = "CONNECTED" | "CONNECTING" | "OFFLINE" | "CALIBRATING";

export interface DeviceTelemetry {
  id: string;
  name: string;
  status: ConnectionState;
  sensor: string;
  controller: string;
  firmwareVersion: string;
  batteryPercentage: number | null;
  i2cAddress: string;
  sampleRateHz: number;
}

export interface CPRSessionRecord {
  id: string;
  startTime: string;
  durationSeconds: number;
  totalCompressions: number;
  averageRate: number;
  targetRateCompliancePct: number;
  averageTiltDegrees: number;
}
