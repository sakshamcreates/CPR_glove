import React, { useState } from 'react';
import { PageContainer } from '../components/common/PageContainer';
import { MetricCard } from '../components/common/MetricCard';
import { StatusIndicator } from '../components/common/StatusIndicator';
import { Button } from '../components/common/Button';
import { AccelerationChart } from '../components/visualization/AccelerationChart';
import { Activity, ShieldCheck, Compass, Sparkles } from 'lucide-react';

export const LiveMonitorPage: React.FC = () => {
  const [viewMode, setViewMode] = useState<'live_offline' | 'demo_preview'>('live_offline');

  const isDemo = viewMode === 'demo_preview';

  return (
    <PageContainer
      eyebrow="LIVE FEEDBACK"
      title="Live CPR Monitor"
      subtitle="Real-time feedback from your SANJEEVANI glove."
      actions={
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-md bg-canvas-secondary border border-border">
            <span className="font-mono text-xs text-content-secondary">DEVICE:</span>
            <span className="font-mono text-xs font-semibold text-content-primary">SANJEEVANI-01</span>
            <span className="text-border">|</span>
            {isDemo ? (
              <StatusIndicator variant="demo" label="DEMO PREVIEW" size="sm" />
            ) : (
              <StatusIndicator status="OFFLINE" label="● OFFLINE" size="sm" />
            )}
          </div>

          <Button
            variant={isDemo ? 'secondary' : 'outline'}
            size="sm"
            onClick={() => setViewMode(isDemo ? 'live_offline' : 'demo_preview')}
          >
            {isDemo ? 'Switch to Live State' : 'View Demo Layout'}
          </Button>
        </div>
      }
    >
      {/* Demo Notice Banner if Demo Mode Active */}
      {isDemo && (
        <div className="mb-6 p-3 rounded-lg bg-canvas-secondary border border-border flex items-center justify-between text-xs font-mono text-content-secondary">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-status-warning" />
            <span className="font-semibold text-content-primary">DEMO PREVIEW ACTIVE:</span>
            <span>Displaying representative CPR feedback. Connect device for live sessions.</span>
          </div>
          <button
            onClick={() => setViewMode('live_offline')}
            className="text-brand-green font-semibold hover:underline"
          >
            Exit Demo
          </button>
        </div>
      )}

      {/* Primary HUD Instrument Layout */}
      <div className="space-y-6">
        {/* Main Rate & Status Header Box */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Main Primary Metric: CPR RATE Dial */}
          <div className="lg:col-span-5 p-6 rounded-xl border border-border bg-white shadow-subtle flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-4">
                <span className="font-mono text-xs font-semibold tracking-wider text-content-secondary uppercase">
                  PRIMARY RHYTHM
                </span>
                {isDemo ? (
                  <StatusIndicator variant="cpr" cprStatus="OPTIMAL" size="sm" label="OPTIMAL" />
                ) : (
                  <span className="font-mono text-xs text-content-muted">Waiting for glove connection.</span>
                )}
              </div>

              <div className="text-center py-6">
                <span className="text-xs font-mono uppercase text-content-secondary block mb-1">
                  CPR RATE
                </span>
                <div className="flex items-baseline justify-center gap-2">
                  <span className="text-6xl sm:text-7xl font-mono font-bold tracking-tight text-content-primary">
                    {isDemo ? '112' : '--'}
                  </span>
                  <span className="text-sm font-mono text-content-secondary font-medium">
                    /min
                  </span>
                </div>
                <div className="mt-4 inline-flex items-center gap-1.5 px-3 py-1 rounded bg-canvas-secondary border border-border text-xs text-content-secondary font-medium">
                  <Activity className="w-3.5 h-3.5 text-brand-green" />
                  Target: 100–120 per minute
                </div>
              </div>
            </div>

            <div className="pt-4 border-t border-border/70 flex items-center justify-between text-xs text-content-secondary">
              <span>Status:</span>
              <span className={isDemo ? 'text-status-success font-medium' : 'text-content-muted'}>
                {isDemo ? 'In Target Cadence' : 'Waiting for glove connection.'}
              </span>
            </div>
          </div>

          {/* Supporting Telemetry 3-Pack */}
          <div className="lg:col-span-7 grid grid-cols-1 sm:grid-cols-3 gap-4">
            <MetricCard
              label="COMPRESSIONS"
              value={isDemo ? '18 / 30' : '--'}
              statusBadge={
                isDemo ? (
                  <span className="flex items-center gap-1 text-[11px] font-mono text-brand-green font-medium">
                    <ShieldCheck className="w-3 h-3" /> ACTIVE
                  </span>
                ) : (
                  <span className="font-mono text-xs text-content-muted">IDLE</span>
                )
              }
              hint={isDemo ? 'Cycle 1' : 'Ready'}
            />

            <MetricCard
              label="HAND POSITION"
              value={isDemo ? 'Optimal' : '--'}
              statusBadge={
                isDemo ? (
                  <span className="flex items-center gap-1 text-[11px] font-mono text-status-success font-medium">
                    <Compass className="w-3 h-3" /> ALIGNED
                  </span>
                ) : (
                  <span className="font-mono text-xs text-content-muted">--</span>
                )
              }
              hint={isDemo ? 'Correct orientation' : 'Sensor idle'}
            />

            <MetricCard
              label="MOTION"
              value={isDemo ? 'Stable' : '--'}
              statusBadge={
                isDemo ? (
                  <span className="flex items-center gap-1 text-[11px] font-mono text-brand-green font-medium">
                    <Sparkles className="w-3 h-3" /> SMOOTH
                  </span>
                ) : (
                  <span className="font-mono text-xs text-content-muted">--</span>
                )
              }
              hint={isDemo ? 'Consistent movement' : 'Stationary'}
            />
          </div>
        </div>

        {/* Live Motion Waveform */}
        <div className="rounded-xl border border-border bg-white p-5 sm:p-6 shadow-subtle space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-border">
            <div>
              <h3 className="text-sm font-bold text-content-primary">
                Live Motion
              </h3>
              <p className="text-xs text-content-secondary">
                Visual compression rhythm from the glove sensor.
              </p>
            </div>
            <span className="font-mono text-xs text-content-muted">
              {isDemo ? 'ACTIVE PREVIEW' : 'STANDBY'}
            </span>
          </div>

          <AccelerationChart
            mode={isDemo ? 'demo' : 'empty'}
            height={160}
            title="Live Motion"
          />
        </div>
      </div>
    </PageContainer>
  );
};
