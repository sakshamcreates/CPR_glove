import React from 'react';
import { PageContainer } from '../components/common/PageContainer';
import { EmptyState } from '../components/common/EmptyState';
import { Button } from '../components/common/Button';
import { History, Play, Filter } from 'lucide-react';

interface SessionsPageProps {
  onNavigate: (path: string) => void;
}

export const SessionsPage: React.FC<SessionsPageProps> = ({ onNavigate }) => {
  return (
    <PageContainer
      eyebrow="HISTORY"
      title="Sessions"
      subtitle="Review your completed CPR practice runs, cadence stability, and positioning."
      actions={
        <div className="flex items-center gap-3">
          <Button
            variant="primary"
            size="sm"
            onClick={() => onNavigate('/live')}
            icon={<Play className="w-3.5 h-3.5" />}
          >
            Start a Session
          </Button>
        </div>
      }
    >
      {/* Session List Container */}
      <div className="bg-white rounded-xl border border-border shadow-subtle overflow-hidden">
        {/* Top Header */}
        <div className="p-4 bg-canvas-secondary/60 border-b border-border flex flex-wrap items-center justify-between gap-3 text-xs font-mono text-content-secondary">
          <div className="flex items-center gap-2">
            <Filter className="w-3.5 h-3.5" />
            <span className="font-semibold text-content-primary">SESSION HISTORY (0 SESSIONS)</span>
          </div>
        </div>

        {/* Empty State */}
        <div className="p-8 sm:p-14">
          <EmptyState
            icon={History}
            badgeText="NO DATA YET"
            title="No sessions recorded yet."
            description="Your completed CPR practice sessions will appear here."
            actionLabel="Start a Session"
            onAction={() => onNavigate('/live')}
            secondaryActionLabel="Device Setup"
            onSecondaryAction={() => onNavigate('/device')}
          />
        </div>

        {/* Informative Table Structure Placeholder */}
        <div className="p-6 bg-canvas-primary/40 border-t border-border">
          <div className="mb-3">
            <span className="font-mono text-xs font-semibold text-content-primary uppercase">
              SESSION HISTORY
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left font-mono text-xs text-content-secondary border border-border rounded bg-white">
              <thead className="bg-canvas-secondary/70 border-b border-border text-content-primary">
                <tr>
                  <th className="py-2.5 px-3 font-semibold">Date</th>
                  <th className="py-2.5 px-3 font-semibold">Duration</th>
                  <th className="py-2.5 px-3 font-semibold">Average Rate</th>
                  <th className="py-2.5 px-3 font-semibold">Motion Consistency</th>
                  <th className="py-2.5 px-3 font-semibold">Position Consistency</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border/60">
                <tr className="text-content-muted">
                  <td className="py-3 px-3 italic">--</td>
                  <td className="py-3 px-3 italic">--</td>
                  <td className="py-3 px-3 italic">-- /min</td>
                  <td className="py-3 px-3 italic">--</td>
                  <td className="py-3 px-3 italic">--</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </PageContainer>
  );
};
