import React from 'react';
import { PageContainer } from '../components/common/PageContainer';
import { Button } from '../components/common/Button';
import { BarChart3, Activity, Compass, ArrowRight, Sparkles, TrendingUp } from 'lucide-react';

interface AnalyticsPageProps {
  onNavigate: (path: string) => void;
}

export const AnalyticsPage: React.FC<AnalyticsPageProps> = ({ onNavigate }) => {
  return (
    <PageContainer
      eyebrow="ANALYTICS"
      title="Performance Analytics"
      subtitle="Insights into rhythm accuracy, hand positioning, and compression consistency."
      actions={
        <span className="inline-flex items-center gap-1.5 px-3 py-1 font-mono text-xs font-semibold bg-canvas-muted text-content-secondary border border-border rounded">
          COMING WITH SESSION DATA
        </span>
      }
    >
      {/* Notice Banner */}
      <div className="p-6 rounded-xl border border-border bg-white shadow-subtle mb-8">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-start sm:items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-canvas-muted flex items-center justify-center text-brand-green shrink-0">
              <BarChart3 className="w-5 h-5 stroke-[1.75]" />
            </div>
            <div>
              <h2 className="text-base font-bold text-content-primary">
                Analytics will appear after your first completed session.
              </h2>
              <p className="text-xs text-content-secondary mt-0.5">
                Completed practice runs will automatically generate insights on rhythm, hand position, and progress over time.
              </p>
            </div>
          </div>
          <Button
            variant="primary"
            size="sm"
            onClick={() => onNavigate('/live')}
            icon={<ArrowRight className="w-3.5 h-3.5" />}
          >
            Start a Session
          </Button>
        </div>
      </div>

      {/* 4 Human-Readable Measurement Sections */}
      <div className="mb-6">
        <h3 className="font-mono text-xs font-semibold tracking-wider text-content-secondary uppercase mb-4">
          WHAT SANJEEVANI MEASURES
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Section 01 */}
          <div className="p-6 rounded-xl border border-border bg-white shadow-subtle flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-3">
                <span className="font-mono text-xs font-semibold px-2 py-0.5 bg-canvas-muted text-brand-green rounded">
                  01
                </span>
                <Activity className="w-4 h-4 text-content-secondary" />
              </div>
              <h4 className="text-base font-bold text-content-primary mb-1">
                CPR RHYTHM
              </h4>
              <p className="text-sm text-content-secondary leading-relaxed">
                How consistently the compression rhythm stayed within the target range (100–120 compressions per minute).
              </p>
            </div>
            <div className="mt-4 pt-3 border-t border-border/60 text-xs font-mono text-content-muted">
              Target: 100–120 per minute
            </div>
          </div>

          {/* Section 02 */}
          <div className="p-6 rounded-xl border border-border bg-white shadow-subtle flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-3">
                <span className="font-mono text-xs font-semibold px-2 py-0.5 bg-canvas-muted text-brand-green rounded">
                  02
                </span>
                <Sparkles className="w-4 h-4 text-content-secondary" />
              </div>
              <h4 className="text-base font-bold text-content-primary mb-1">
                MOTION CONSISTENCY
              </h4>
              <p className="text-sm text-content-secondary leading-relaxed">
                How stable the compression movement was throughout the session, helping you track rescuer stamina and pace.
              </p>
            </div>
            <div className="mt-4 pt-3 border-t border-border/60 text-xs font-mono text-content-muted">
              Smooth, repeatable movement
            </div>
          </div>

          {/* Section 03 */}
          <div className="p-6 rounded-xl border border-border bg-white shadow-subtle flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-3">
                <span className="font-mono text-xs font-semibold px-2 py-0.5 bg-canvas-muted text-brand-green rounded">
                  03
                </span>
                <Compass className="w-4 h-4 text-content-secondary" />
              </div>
              <h4 className="text-base font-bold text-content-primary mb-1">
                HAND POSITION
              </h4>
              <p className="text-sm text-content-secondary leading-relaxed">
                How consistently the glove remained correctly positioned and aligned during chest compressions.
              </p>
            </div>
            <div className="mt-4 pt-3 border-t border-border/60 text-xs font-mono text-content-muted">
              Vertical palm alignment
            </div>
          </div>

          {/* Section 04 */}
          <div className="p-6 rounded-xl border border-border bg-white shadow-subtle flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-3">
                <span className="font-mono text-xs font-semibold px-2 py-0.5 bg-canvas-muted text-brand-green rounded">
                  04
                </span>
                <TrendingUp className="w-4 h-4 text-content-secondary" />
              </div>
              <h4 className="text-base font-bold text-content-primary mb-1">
                SESSION PROGRESS
              </h4>
              <p className="text-sm text-content-secondary leading-relaxed">
                How performance changes across practice sessions, helping you build muscle memory and confidence.
              </p>
            </div>
            <div className="mt-4 pt-3 border-t border-border/60 text-xs font-mono text-content-muted">
              Session-over-session trend
            </div>
          </div>
        </div>
      </div>
    </PageContainer>
  );
};
