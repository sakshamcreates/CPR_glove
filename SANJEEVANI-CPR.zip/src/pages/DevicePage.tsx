import React from 'react';
import { PageContainer } from '../components/common/PageContainer';
import { StatusIndicator } from '../components/common/StatusIndicator';
import { Button } from '../components/common/Button';
import { HardwareDiagram } from '../components/visualization/HardwareDiagram';
import { Radio, Sliders } from 'lucide-react';

export const DevicePage: React.FC = () => {
  return (
    <PageContainer
      eyebrow="DEVICE"
      title="SANJEEVANI Device"
      subtitle="Glove status, hardware info, and setup."
      actions={
        <div className="flex items-center gap-3">
          <StatusIndicator status="OFFLINE" label="● OFFLINE" />
        </div>
      }
    >
      {/* Top Device Specs Card */}
      <div className="bg-white rounded-xl border border-border shadow-subtle p-6 sm:p-8 mb-8">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 pb-6 border-b border-border">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="font-mono text-base font-bold text-content-primary">
                SANJEEVANI-01
              </span>
              <span className="font-mono text-xs px-2 py-0.5 bg-canvas-muted text-content-secondary rounded border border-border">
                DEVICE UNIT
              </span>
            </div>
            <p className="text-xs text-content-secondary">
              Smart CPR Feedback Glove
            </p>
          </div>

          {/* Action Buttons (Disabled placeholders in Phase 1) */}
          <div className="flex flex-wrap items-center gap-3">
            <Button
              variant="secondary"
              size="md"
              disabled={true}
              icon={<Sliders className="w-4 h-4" />}
            >
              Calibrate
            </Button>
            <Button
              variant="primary"
              size="md"
              disabled={true}
              icon={<Radio className="w-4 h-4" />}
            >
              Connect Device
            </Button>
          </div>
        </div>

        {/* Simplified Device Parameters Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4 pt-6">
          <div className="p-3.5 rounded-lg bg-canvas-primary/60 border border-border/80">
            <span className="font-mono text-[11px] text-content-secondary uppercase block mb-1">
              STATUS
            </span>
            <span className="font-mono text-sm font-semibold text-content-primary flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-content-muted" />
              Offline
            </span>
          </div>

          <div className="p-3.5 rounded-lg bg-canvas-primary/60 border border-border/80">
            <span className="font-mono text-[11px] text-content-secondary uppercase block mb-1">
              CONTROLLER
            </span>
            <span className="font-mono text-sm font-semibold text-content-primary">
              ESP32-S3
            </span>
          </div>

          <div className="p-3.5 rounded-lg bg-canvas-primary/60 border border-border/80">
            <span className="font-mono text-[11px] text-content-secondary uppercase block mb-1">
              MOTION SENSOR
            </span>
            <span className="font-mono text-sm font-semibold text-content-primary">
              MPU6050
            </span>
          </div>

          <div className="p-3.5 rounded-lg bg-canvas-primary/60 border border-border/80">
            <span className="font-mono text-[11px] text-content-secondary uppercase block mb-1">
              FEEDBACK
            </span>
            <span className="font-mono text-sm font-semibold text-content-primary">
              Light · Sound · Vibration
            </span>
          </div>

          <div className="p-3.5 rounded-lg bg-canvas-primary/60 border border-border/80">
            <span className="font-mono text-[11px] text-content-secondary uppercase block mb-1">
              FIRMWARE
            </span>
            <span className="font-mono text-sm font-semibold text-content-primary">
              --
            </span>
          </div>

          <div className="p-3.5 rounded-lg bg-canvas-primary/60 border border-border/80">
            <span className="font-mono text-[11px] text-content-secondary uppercase block mb-1">
              BATTERY
            </span>
            <span className="font-mono text-sm font-semibold text-content-primary">
              --
            </span>
          </div>
        </div>
      </div>

      {/* Simple Visual Architecture */}
      <div className="space-y-4">
        <h3 className="font-mono text-xs font-semibold tracking-wider text-content-secondary uppercase">
          SYSTEM ARCHITECTURE
        </h3>
        <HardwareDiagram />
      </div>
    </PageContainer>
  );
};
