import React from 'react';
import { PageContainer } from '../components/common/PageContainer';
import { MetricCard } from '../components/common/MetricCard';
import { StatusIndicator } from '../components/common/StatusIndicator';
import { Button } from '../components/common/Button';
import { EmptyState } from '../components/common/EmptyState';
import { Radio, ArrowRight, Activity, Settings, History } from 'lucide-react';

interface DashboardPageProps {
  onNavigate: (path: string) => void;
}

export const DashboardPage: React.FC<DashboardPageProps> = ({ onNavigate }) => {
  return (
    <PageContainer
      eyebrow="OVERVIEW"
      title="CPR Overview"
      subtitle="System status and practice summary for your connected glove."
      actions={
        <div className="flex items-center gap-3">
          <StatusIndicator status="OFFLINE" label="● OFFLINE" />
          <Button
            variant="primary"
            size="sm"
            onClick={() => onNavigate('/live')}
            icon={<ArrowRight className="w-3.5 h-3.5" />}
          >
            Open Live Monitor
          </Button>
        </div>
      }
    >
      {/* Simplified Metric Tiles */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <MetricCard
          label="CPR RATE"
          value="--"
          unit="/min"
          statusBadge={<span className="font-mono text-xs text-content-muted">OFFLINE</span>}
        />
        <MetricCard
          label="COMPRESSIONS"
          value="--"
          statusBadge={<span className="font-mono text-xs text-content-muted">IDLE</span>}
        />
        <MetricCard
          label="HAND POSITION"
          value="--"
          statusBadge={<span className="font-mono text-xs text-content-muted">NO SIGNAL</span>}
        />
        <MetricCard
          label="SESSION"
          value="--"
          statusBadge={<span className="font-mono text-xs text-content-muted">INACTIVE</span>}
        />
      </div>

      {/* Main Empty State Container */}
      <div className="bg-white rounded-xl border border-border p-6 sm:p-10 shadow-subtle mb-8">
        <EmptyState
          icon={Radio}
          badgeText="GLOVE OFFLINE"
          title="Connect your SANJEEVANI glove to begin."
          description="Once connected, live CPR feedback will appear here."
          actionLabel="Open Live Monitor"
          onAction={() => onNavigate('/live')}
          secondaryActionLabel="Device Setup"
          onSecondaryAction={() => onNavigate('/device')}
        />
      </div>

      {/* Quick Launch Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="p-5 rounded-lg border border-border bg-white/70 shadow-subtle flex flex-col justify-between">
          <div>
            <div className="w-8 h-8 rounded bg-canvas-muted flex items-center justify-center text-brand-green mb-3">
              <Activity className="w-4 h-4" />
            </div>
            <h3 className="text-sm font-bold text-content-primary mb-1">
              Live Monitor
            </h3>
            <p className="text-xs text-content-secondary leading-relaxed">
              Real-time CPR rate, rhythm guidance, and hand positioning feedback.
            </p>
          </div>
          <button
            onClick={() => onNavigate('/live')}
            className="mt-4 text-xs font-semibold text-brand-green flex items-center gap-1 hover:underline"
          >
            Launch Monitor <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="p-5 rounded-lg border border-border bg-white/70 shadow-subtle flex flex-col justify-between">
          <div>
            <div className="w-8 h-8 rounded bg-canvas-muted flex items-center justify-center text-brand-green mb-3">
              <History className="w-4 h-4" />
            </div>
            <h3 className="text-sm font-bold text-content-primary mb-1">
              Session History
            </h3>
            <p className="text-xs text-content-secondary leading-relaxed">
              Review completed practice sessions, average rhythm rate, and consistency.
            </p>
          </div>
          <button
            onClick={() => onNavigate('/sessions')}
            className="mt-4 text-xs font-semibold text-brand-green flex items-center gap-1 hover:underline"
          >
            View Sessions <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="p-5 rounded-lg border border-border bg-white/70 shadow-subtle flex flex-col justify-between">
          <div>
            <div className="w-8 h-8 rounded bg-canvas-muted flex items-center justify-center text-brand-green mb-3">
              <Settings className="w-4 h-4" />
            </div>
            <h3 className="text-sm font-bold text-content-primary mb-1">
              Device Setup
            </h3>
            <p className="text-xs text-content-secondary leading-relaxed">
              Inspect glove connection status, sensor state, and feedback options.
            </p>
          </div>
          <button
            onClick={() => onNavigate('/device')}
            className="mt-4 text-xs font-semibold text-brand-green flex items-center gap-1 hover:underline"
          >
            Inspect Device <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </PageContainer>
  );
};
